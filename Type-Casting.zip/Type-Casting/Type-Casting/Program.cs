﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Type_Casting
{
    class Program
    {
        static void Main(string[] args)
        {
            //Implicit Type Casting
            int x = 9;
            double y = x;  

            Console.WriteLine(x);
            Console.WriteLine(y);

            //Explicit Type Casting
            double a = 9.78;
            int b = (int)a;    

            Console.WriteLine(a);   
            Console.WriteLine(b);
            Console.Read();
        }
    }
}
