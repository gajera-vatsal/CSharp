﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Logical
{
    class Program
    {
        static void Main(string[] args)
        {
            //Logical AND
            int x = 5;
            Console.WriteLine(x > 3 && x < 10);

            //Logical OR
            Console.WriteLine(x > 3 || x < 4); 

            //Lgical NOT
            Console.WriteLine(!(x > 3 && x < 10));

            Console.Read();
        }
    }
}
