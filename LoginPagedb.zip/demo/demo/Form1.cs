﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Demo.mdf;Integrated Security=True;User Instance=True");
            string sql = "select * from login where unm='" + textBox1.Text + "' and pwd='" + textBox2.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataSet ds = new DataSet();
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count >= 1)
            {
                home F2 = new home();
                F2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid!", "Database", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clear();
            }
        }

        private void clear()
        {
            textBox1.Text = textBox2.Text = "";
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}
