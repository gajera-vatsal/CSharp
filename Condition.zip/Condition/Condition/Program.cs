﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Condition
{
    class Program
    {
        static void Main(string[] args)
        {
            //If Condition
            int x = 20;
            int y = 18;
            if (x > y)
            {
                Console.WriteLine("x is greater than y");
            }

            //If-Else Condition
            int time = 20;
            if (time < 18)
            {
                Console.WriteLine("Good day.");
            }
            else
            {
                Console.WriteLine("Good evening.");
            }

            //Else-If Condition
            if (time < 10)
            {
                Console.WriteLine("Good morning.");
            }
            else if (time < 20)
            {
                Console.WriteLine("Good day.");
            }
            else
            {
                Console.WriteLine("Good evening.");
            }
            Console.Read();
        }
    }
}
