﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GetFromUser
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Your name:");
            string userName = Console.ReadLine();
            Console.WriteLine("Name : " + userName);
            Console.Read();
        }
    }
}
