﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;

            //While Loop
            while (i < 5)
            {
                Console.WriteLine(i);
                i++;
            }

            //For Loop
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine(i);
            }

            //For Each Loop
            string[] cars = { "Volvo", "Audi", "Ford", "Mustang" };
            foreach (string a in cars)
            {
                Console.WriteLine(a);
            }
            Console.Read();
        }
    }
}
